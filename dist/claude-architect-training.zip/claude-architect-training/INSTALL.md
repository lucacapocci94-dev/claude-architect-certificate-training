# Claude Architect — Foundations Training Program

A self-contained, drop-in package that turns any local project into an interactive training program for the **Claude Certified Architect — Foundations** certification.

---

## What's inside

```
.claude/
  bin/state.py              Student profile / progress / notes manager
  hooks/                    SessionStart, PreCompact, PostToolUse hooks
  settings.json             Hook wiring
  commands/                 16 slash commands (/start, /next, /progress, /help, ...)
  skills/                   28 micro-lesson skills across 5 tracks
  state/
    schema/                 Templates committed; per-student state stays local
    README.md
CLAUDE.md                   Orchestrator protocol + instructor persona
.gitignore                  Ignores per-student state files
```

---

## How to install — three paths

Pick whichever fits your situation.

### Path A — Drop into an existing project (recommended)

You already have a project where you want to learn Claude Code on real code.

```bash
# from the directory where you unzipped this package:
cp -r .claude /path/to/your-project/
cp CLAUDE.md /path/to/your-project/
cat .gitignore >> /path/to/your-project/.gitignore   # merge ignores
cd /path/to/your-project
claude
```

> ⚠️ **Warning:** if your project already has a `CLAUDE.md`, the copy above overwrites it. Either back yours up first, or append the relevant parts from this one by hand. Same for an existing `.claude/` folder — merge, don't blindly overwrite.

That's it. The SessionStart hook will greet you and route you through `/start` since you don't have a profile yet.

### Path B — Use the package as its own training project

You don't have a project to use, or you want to keep training separate from your work.

```bash
cd ~                                  # or wherever you keep code
unzip claude-architect-training.zip   # creates ./claude-architect-training/
cd claude-architect-training
claude
```

You'll be doing the lessons inside this folder. That's fine — most lessons that *require* real code will tell you to open a second terminal and `cd` into one of your own repos at the right moment.

### Path C — Install as a user-level plugin

You want the training available in every project on this machine.

```bash
mkdir -p ~/.claude/plugins
cp -r claude-architect-training ~/.claude/plugins/architect-training
```

The skills and commands become available everywhere. Two caveats:

1. The `.claude/state/` files (your progress) will live wherever you launch `claude` from. If you want a single shared store, leave Path B installed alongside and just `cd` there.
2. The hooks fire globally — fine, but if you have other hooks you may need to merge `settings.json` by hand.

---

## First run

Whichever install path you pick, launch:

```bash
claude
```

The SessionStart hook will inject a `<training-state>` block saying you're a new student. Claude will offer to run `/start`. Say yes — it takes 2 minutes:

1. Asks your name
2. Asks your level (absolute beginner / used chat only / tried Claude Code / regular user)
3. Asks your goals (cert / day-to-day productivity / specific project)
4. Captures optional project context
5. Routes you to the right starting lesson

From then on:

| Command | Use |
|---|---|
| `/next` | Resume the next lesson |
| `/progress [track]` | See what you've completed (optionally filtered to one module) |
| `/syllabus [track]` | See the full curriculum (or one module) |
| `/help` | List every command with explanations |
| `/remember <text>` | Save something to remember about your project |
| `/reset-progress` | Wipe progress (`--hard` also wipes profile) |

Italian aliases work too: `/programma`, `/avanzamento`, `/aiuto`.

---

## Curriculum at a glance

| Track | Lessons | What you learn |
|---|---|---|
| **Foundations Zero** | 5 | What Claude Code is → install → first session → `/init` → CLAUDE.md hierarchy |
| **Core Concepts** | 9 | Rules · slash commands · skills · hooks · permissions · subagents · plan mode · context · MCP |
| **Workflow** | 5 | Brainstorming · spec-driven · plan in depth · iterative refinement · TDD |
| **Plugins** | 4 | What plugins are · install · `superpowers` walkthrough · authoring your own |
| **Domains** | 5 | Certification domains 1–5 (exam-focused) |
| **Total** | **28** | ~5–10 min each |

---

## Requirements

- [Claude Code](https://claude.com/product/claude-code) installed (`npm install -g @anthropic-ai/claude-code`)
- Node.js ≥ 18
- Python 3 (used by the state manager — pre-installed on macOS/Linux)
- Authentication: a Claude Pro/Max subscription or an `ANTHROPIC_API_KEY`

If `claude --version` works, you're set.

---

## How progress is stored

Everything per-student lives in `.claude/state/` (git-ignored):

- `profile.json` — name, level, goals
- `progress.json` — completed lessons, current pointer
- `notes.md` — things you asked Claude to remember

You can wipe them at any time with `/reset-progress` or by deleting the files.

To back up your progress, just copy the three files. To move to another machine, copy them over.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| `claude` says "command not found" | Install Claude Code: `npm install -g @anthropic-ai/claude-code` and re-source your shell rc |
| Hook fails: "python3 not found" | Install Python 3 (`brew install python` / `apt install python3`) |
| Progress disappears between sessions | You launched `claude` from a different directory. Always launch from the project root that holds `.claude/state/` |
| Permission prompts on every `state.py` call | Add `.claude/settings.local.json` with an allow rule — covered in `/lesson permissions-intro` |

---

## License & feedback

This is internal Accenture training material. Feedback welcome via the program owner.
